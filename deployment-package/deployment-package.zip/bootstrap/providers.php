<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\NavigationMenuServiceProvider::class,
    App\Providers\SettingsServiceProvider::class,
    App\Providers\SocialiteServiceProvider::class,
    App\Providers\ViewServiceProvider::class,
];
